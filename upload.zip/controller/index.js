module.exports = {
    Auth: require("./auth.controller"),
    Category:require("./category.controller"),
    Tag:require("./tag.controller")
}
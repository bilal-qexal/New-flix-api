module.exports = {
    Auth: require('./auth.middleware')
}
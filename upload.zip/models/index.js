module.exports = {
    User: require("./user.model"),
    EmailVerification: require("./email_verification.model"),
    PhoneVerification: require("./sms_verification.model"),
    ForgetPassword: require("./forgetPassword.model"),
    Category:require("./category.model"),
    Tag:require("./tag.model")
}
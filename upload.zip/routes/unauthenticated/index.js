const express = require("express");
const router = express.Router();
//Routes
const authRoutes = require("./auth.routes");
const tagRoutes = require("./tag.routes");
const categoryRoutes = require("./category.routes");

router.use("/auth", authRoutes);
router.use("/tag",tagRoutes);
router.use("/category",categoryRoutes);

module.exports = router;